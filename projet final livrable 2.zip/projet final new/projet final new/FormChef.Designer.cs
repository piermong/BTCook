﻿namespace projet_final_new
{
    partial class FormChef
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtIngredients = new TextBox();
            txtPrix = new TextBox();
            txtQuantité = new TextBox();
            txtOrigine = new TextBox();
            txtNom = new TextBox();
            label1 = new Label();
            cmbType = new ComboBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btCréation = new Button();
            cmbMetro = new ComboBox();
            label8 = new Label();
            SuspendLayout();
            // 
            // txtIngredients
            // 
            txtIngredients.Location = new Point(344, 79);
            txtIngredients.Name = "txtIngredients";
            txtIngredients.Size = new Size(121, 23);
            txtIngredients.TabIndex = 0;
            txtIngredients.TextChanged += txtIngredients_TextChanged;
            // 
            // txtPrix
            // 
            txtPrix.Location = new Point(344, 108);
            txtPrix.Name = "txtPrix";
            txtPrix.Size = new Size(121, 23);
            txtPrix.TabIndex = 1;
            txtPrix.TextChanged += txtPrix_TextChanged;
            // 
            // txtQuantité
            // 
            txtQuantité.Location = new Point(344, 137);
            txtQuantité.Name = "txtQuantité";
            txtQuantité.Size = new Size(121, 23);
            txtQuantité.TabIndex = 2;
            txtQuantité.TextChanged += txtQuantité_TextChanged;
            // 
            // txtOrigine
            // 
            txtOrigine.Location = new Point(344, 166);
            txtOrigine.Name = "txtOrigine";
            txtOrigine.Size = new Size(121, 23);
            txtOrigine.TabIndex = 3;
            txtOrigine.TextChanged += txtOrigine_TextChanged;
            // 
            // txtNom
            // 
            txtNom.Location = new Point(344, 195);
            txtNom.Name = "txtNom";
            txtNom.Size = new Size(121, 23);
            txtNom.TabIndex = 4;
            txtNom.TextChanged += txtNom_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(344, 24);
            label1.Name = "label1";
            label1.Size = new Size(105, 15);
            label1.TabIndex = 6;
            label1.Text = "Création d'un plat ";
            // 
            // cmbType
            // 
            cmbType.FormattingEnabled = true;
            cmbType.Items.AddRange(new object[] { "Entrée", "Plat", "Dessert" });
            cmbType.Location = new Point(344, 224);
            cmbType.Name = "cmbType";
            cmbType.Size = new Size(121, 23);
            cmbType.TabIndex = 7;
            cmbType.SelectedIndexChanged += cmbType_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(256, 82);
            label2.Name = "label2";
            label2.Size = new Size(72, 15);
            label2.TabIndex = 8;
            label2.Text = "Ingrédients :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(296, 111);
            label3.Name = "label3";
            label3.Size = new Size(32, 15);
            label3.TabIndex = 9;
            label3.Text = "Prix :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(269, 140);
            label4.Name = "label4";
            label4.Size = new Size(59, 15);
            label4.TabIndex = 10;
            label4.Text = "Quantité :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(276, 169);
            label5.Name = "label5";
            label5.Size = new Size(52, 15);
            label5.TabIndex = 11;
            label5.Text = "Origine :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(290, 198);
            label6.Name = "label6";
            label6.Size = new Size(40, 15);
            label6.TabIndex = 12;
            label6.Text = "Nom :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(290, 227);
            label7.Name = "label7";
            label7.Size = new Size(38, 15);
            label7.TabIndex = 13;
            label7.Text = "Type :";
            // 
            // btCréation
            // 
            btCréation.BackColor = Color.Coral;
            btCréation.Location = new Point(326, 311);
            btCréation.Name = "btCréation";
            btCréation.Size = new Size(158, 23);
            btCréation.TabIndex = 14;
            btCréation.Text = "Créer un nouveau plat";
            btCréation.UseVisualStyleBackColor = false;
            btCréation.Click += btCréation_Click;
            // 
            // cmbMetro
            // 
            cmbMetro.FormattingEnabled = true;
            cmbMetro.Items.AddRange(new object[] { "Abbesses", "Alésia", "Alexandre Dumas", "Alma - Marceau", "Anvers", "Argentine", "Arts et Métiers", "Assemblée Nationale", "Avenue Emile Zola", "Avron", "Balard", "Barbès - Rochechouart", "Bastille", "Bel-Air", "Belleville", "Bercy", "Bibliothèque François Mitterrand", "Bir-Hakeim", "Blanche", "Boissière", "Bolivar", "Bonne Nouvelle", "Botzaris", "Boucicaut", "Bourse", "Bréguet-Sabin", "Brochant", "Buttes Chaumont", "Buzenval", "Cadet", "Cambronne", "Campo-Formio", "Cardinal Lemoine", "Censier - Daubenton", "Champs-Elysées - Clemenceau", "Chardon Lagache", "Charles de Gaulle - Etoile", "Charles Michels", "Charonne", "Château de Vincennes", "Château d'Eau", "Château Landon", "Château Rouge", "Châtelet", "Chaussée d'Antin - La Fayette", "Chemin Vert", "Chevaleret", "Cité", "Cluny - La Sorbonne", "Colonel Fabien", "Commerce", "Concorde", "Convention", "Corentin Cariou", "Corvisart", "Cour Saint-Emilion", "Courcelles", "Couronnes", "Crimée", "Danube", "Daumesnil", "Denfert-Rochereau", "Dugommier", "Dupleix", "Duroc", "Ecole Militaire", "Edgar Quinet", "Eglise d'Auteuil", "Etienne Marcel", "Europe", "Exelmans", "Faidherbe - Chaligny", "Falguière", "Félix Faure", "Filles du Calvaire", "Franklin D. Roosevelt", "Gaîté", "Gambetta", "Gare d'Austerlitz", "Gare de l'Est", "Gare de Lyon", "Gare du Nord", "George V", "Glacière", "Goncourt", "Grands Boulevards", "Guy Môquet", "Havre-Caumartin", "Hôtel de Ville", "Iéna", "Invalides", "Jacques Bonsergent", "Jasmin", "Jaurès", "Javel - André Citroën", "Jourdain", "Jules Joffrin", "Jussieu", "Kléber", "La Chapelle", "La Fourche", "La Motte-Picquet - Grenelle", "La Muette", "La Tour-Maubourg", "Lamarck - Caulaincourt", "Laumière", "Le Peletier", "Ledru-Rollin", "Les Gobelins", "Les Halles", "Liège", "Louis Blanc", "Lourmel", "Louvre - Rivoli", "Mabillon", "Madeleine", "Maison Blanche", "Malesherbes", "Maraîchers", "Marcadet - Poissonniers", "Marx Dormoy", "Maubert - Mutualité", "Ménilmontant", "Michel Bizot", "Michel-Ange - Auteuil", "Michel-Ange - Molitor", "Mirabeau", "Miromesnil", "Monceau", "Montgallet", "Montparnasse Bienvenue", "Mouton-Duvernet", "Nation", "Nationale", "Notre-Dame des Champs", "Notre-Dame-de-Lorette", "Oberkampf", "Odéon", "Olympiades", "Opéra", "Ourcq", "Palais Royal - Musée du Louvre", "Parmentier", "Passy", "Pasteur", "Pelleport", "Père Lachaise", "Pereire", "Pernety", "Philippe Auguste", "Picpus", "Pigalle", "Place de Clichy", "Place des Fêtes", "Place d'Italie", "Place Monge", "Plaisance", "Poissonnière", "Pont Cardinet", "Pont Marie (Cité des Arts)", "Pont Neuf", "Porte Dauphine", "Porte d'Auteuil", "Porte de Bagnolet", "Porte de Champerret", "Porte de Charenton", "Porte de Choisy", "Porte de Clichy", "Porte de Clignancourt", "Porte de la Chapelle", "Porte de la Villette", "Porte de Montreuil", "Porte de Pantin", "Porte de Saint-Cloud", "Porte de Saint-Ouen", "Porte de Vanves", "Porte de Versailles", "Porte de Vincennes", "Porte des Lilas", "Porte d'Italie", "Porte d'Ivry", "Porte Dorée", "Porte d'Orléans", "Porte Maillot", "Pré-Saint-Gervais", "Pyramides", "Pyrénées", "Quai de la Gare", "Quai de la Rapée", "Quatre Septembre", "Rambuteau", "Ranelagh", "Raspail", "Réaumur - Sébastopol", "Rennes", "République", "Reuilly - Diderot", "Richard-Lenoir", "Richelieu - Drouot", "Riquet", "Rome", "Rue de la Pompe", "Rue des Boulets", "Rue du Bac", "Rue Saint-Maur", "Saint-Ambroise", "Saint-Augustin", "Saint-Fargeau", "Saint-François-Xavier", "Saint-Georges", "Saint-Germain-des-Prés", "Saint-Jacques", "Saint-Lazare", "Saint-Marcel", "Saint-Michel", "Saint-Paul (Le Marais)", "Saint-Philippe du Roule", "Saint-Placide", "Saint-Sébastien - Froissart", "Saint-Sulpice", "Ségur", "Sentier", "Sèvres - Babylone", "Sèvres-Lecourbe", "Simplon", "Solférino", "Stalingrad", "Strasbourg - Saint-Denis", "Sully - Morland", "Télégraphe", "Temple", "Ternes", "Tolbiac", "Trinité - d'Estienne d'Orves", "Trocadéro", "Tuileries", "Vaneau", "Varenne", "Vaugirard", "Vavin", "Victor Hugo", "Villiers", "Volontaires", "Voltaire", "Wagram" });
            cmbMetro.Location = new Point(344, 253);
            cmbMetro.Name = "cmbMetro";
            cmbMetro.Size = new Size(121, 23);
            cmbMetro.TabIndex = 15;
            cmbMetro.SelectedIndexChanged += cmbMetro_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(283, 256);
            label8.Name = "label8";
            label8.Size = new Size(45, 15);
            label8.TabIndex = 16;
            label8.Text = "Metro :";
            // 
            // FormChef
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label8);
            Controls.Add(cmbMetro);
            Controls.Add(btCréation);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(cmbType);
            Controls.Add(label1);
            Controls.Add(txtNom);
            Controls.Add(txtOrigine);
            Controls.Add(txtQuantité);
            Controls.Add(txtPrix);
            Controls.Add(txtIngredients);
            Name = "FormChef";
            Text = "FormChef";
            Load += FormChef_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtIngredients;
        private TextBox txtPrix;
        private TextBox txtQuantité;
        private TextBox txtOrigine;
        private TextBox txtNom;
        private Label label1;
        private ComboBox cmbType;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button btCréation;
        private ComboBox cmbMetro;
        private Label label8;
    }
}