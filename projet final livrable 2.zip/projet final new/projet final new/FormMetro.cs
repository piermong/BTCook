﻿using System.Data;
using System.Windows.Forms;
using projet_final_new;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace projet_final_new
{
    public partial class FormMetro : Form
    {
        private Carte carte;
        private float zoomFactor = 1.0f;
        private const float zoomStep = 0.1f;
        private PointF zoomCenter;
        private FormChemin _formChemin;
        private Button btnOuvrirFormChemin; // Bouton global

        public FormMetro(List<string> stationsPlats, string stationClient, int matriculeCommande)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;

            // Création de l'objet Carte et construction du graphe avec les données du fichier CSV
            carte = new Carte();
            string nomFichier = "MetroParisModif.csv";
            string cheminFichier = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, nomFichier);
            carte.ConstruireGraphe(cheminFichier);

            // Lier l'événement Paint au dessin du graphe
            this.Paint += DessinerGraphe;

            // Initialiser FormChemin et le cacher
            _formChemin = new FormChemin(carte, stationsPlats, stationClient, matriculeCommande);
            _formChemin.Hide(); // On cache la fenêtre de comparaison au départ

            // Création et configuration du bouton pour afficher FormChemin
            btnOuvrirFormChemin = new Button();
            btnOuvrirFormChemin.Text = "Afficher le chemin";
            btnOuvrirFormChemin.AutoSize = true;
            btnOuvrirFormChemin.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnOuvrirFormChemin.Location = new Point(this.ClientSize.Width - 200, this.ClientSize.Height - 60);

            // Événement pour afficher ou amener FormChemin au premier plan
            btnOuvrirFormChemin.Click += (s, e) =>
            {
                if (_formChemin.Visible)
                    _formChemin.BringToFront();
                else
                    _formChemin.Show();
            };

            this.Controls.Add(btnOuvrirFormChemin);

            // Mise à jour de la position du bouton lors du redimensionnement du formulaire
            this.Resize += (s, e) =>
            {
                btnOuvrirFormChemin.Location = new Point(this.ClientSize.Width - btnOuvrirFormChemin.Width - 20,
                                                         this.ClientSize.Height - btnOuvrirFormChemin.Height - 20);
            };
        }




        /// <summary>
        /// Gère l'événement de la molette de souris pour le zoom.
        /// </summary>
        /// <param name="sender">L'objet source de l'événement.</param>
        /// <param name="e">Les données de l'événement de la molette.</param>
        private void Form1_MouseWheel(object sender, MouseEventArgs e)
        {
            // Définir le centre du zoom à la position actuelle de la souris
            zoomCenter = new PointF(e.X, e.Y);

            // Modifier le facteur de zoom en fonction de la direction de la molette
            if (e.Delta > 0)
            {
                // Zoom avant
                zoomFactor += zoomStep;
                if (zoomFactor > 5.0f) zoomFactor = 5.0f; // Limite le zoom à un facteur de 5
            }
            else
            {
                // Zoom arrière
                zoomFactor -= zoomStep;
                if (zoomFactor < 0.2f) zoomFactor = 0.2f; // Limite le zoom à 0.2
            }

            // Redessiner le formulaire pour appliquer le zoom
            this.Invalidate(); // Forcer le redessinage du formulaire
        }


        /// <summary>
        /// Dessine le graphe des stations et des arcs sur le formulaire.
        /// </summary>
        /// <param name="sender">L'objet source de l'événement.</param>
        /// <param name="e">Les données de l'événement de dessin.</param>
        private void DessinerGraphe(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.White);

            // Applique le zoom et le centrage
            g.TranslateTransform(zoomCenter.X, zoomCenter.Y);
            g.ScaleTransform(zoomFactor, zoomFactor);
            g.TranslateTransform(-zoomCenter.X, -zoomCenter.Y);

            // Active l'antialiasing pour un rendu plus lisse
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Trouver les valeurs minimales et maximales pour la latitude et la longitude
            double minLat = double.MaxValue;
            double maxLat = 0;
            double minLon = double.MaxValue;
            double maxLon = 0;

            // Calculer les valeurs min/max pour latitude et longitude des stations
            foreach (var station in carte.Stations)
            {
                if (station.Latitude < minLat) minLat = station.Latitude;
                if (station.Latitude > maxLat) maxLat = station.Latitude;
                if (station.Longitude < minLon) minLon = station.Longitude;
                if (station.Longitude > maxLon) maxLon = station.Longitude;
            }

            // Définir les dimensions de la zone de dessin
            int marge = 50;
            int largeurEcran = this.ClientSize.Width - 2 * marge;
            int hauteurEcran = this.ClientSize.Height - 2 * marge;
            int rayonSommet = 10; // Rayon des sommets (stations)

            Dictionary<string, PointF> positions = new Dictionary<string, PointF>();

            // Calculer les positions des stations sur l'écran
            foreach (var station in carte.Stations)
            {
                station.X = (float)((station.Longitude - minLon) / (maxLon - minLon) * largeurEcran) + marge;
                station.Y = (float)((1 - (station.Latitude - minLat) / (maxLat - minLat)) * hauteurEcran) + marge;

                positions[station.Nom] = new PointF(station.X, station.Y);
            }

            // Dessiner les arcs (lignes entre stations)
            foreach (var arc in carte.Arcs)
            {
                if (positions.TryGetValue(arc.Depart.Nom, out PointF depart) && positions.TryGetValue(arc.Arrivee.Nom, out PointF arrivee))
                {
                    // Reculer légèrement le point d'arrivée pour éviter de chevaucher le sommet
                    PointF arriveeAjustee = ReculerPoint(arrivee, depart, rayonSommet);

                    Pen pen = new Pen(arc.CouleurLigne, 3);
                    g.DrawLine(pen, depart, arriveeAjustee); // Dessiner la ligne de l'arc
                    DessinerFleche(g, pen, depart, arriveeAjustee); // Dessiner la flèche
                }
            }

            // Dessiner les sommets (stations)
            foreach (var station in carte.Stations)
            {
                PointF position = new PointF(station.X, station.Y);
                Brush brush = Brushes.Gray;
                g.FillEllipse(brush, position.X - rayonSommet, position.Y - rayonSommet, rayonSommet * 2, rayonSommet * 2); // Dessiner le cercle de la station

                string nomAffiche = FormaterNomStation(station.Nom); // Formater le nom de la station
                Font font = new Font("Arial", 8);
                SizeF textSize = g.MeasureString(nomAffiche, font);
                PointF textPosition = new PointF(position.X - textSize.Width / 2, position.Y - textSize.Height / 2); // Centrer le texte
                g.DrawString(nomAffiche, font, Brushes.Black, textPosition); // Dessiner le nom de la station
            }
        }


        /// <summary>
        /// Formate le nom d'une station pour l'affichage.
        /// </summary>
        /// <param name="nom">Le nom de la station.</param>
        /// <returns>Le nom formaté de la station.</returns>
        private string FormaterNomStation(string nom)
        {
            if (nom.StartsWith("Château de "))
            {
                string resteNom = nom.Substring(11); // Enlève "Château de "
                return "Cha " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Porte de "))
            {
                string resteNom = nom.Substring(9); // Enlève "Porte de "
                return "Prt " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Porte d'"))
            {
                string resteNom = nom.Substring(8); // Enlève "Porte d'"
                return "Prt " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Porte des "))
            {
                string resteNom = nom.Substring(10); // Enlève "Porte des "
                return "Prt " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Porte "))
            {
                string resteNom = nom.Substring(6); // Enlève "Porte "
                return "Prt " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Pont "))
            {
                string resteNom = nom.Substring(5); // Enlève "Pont "
                return "Pnt " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Place de "))
            {
                string resteNom = nom.Substring(9); // Enlève "Place de "
                return "Plc " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Place des "))
            {
                string resteNom = nom.Substring(10); // Enlève "Place des "
                return "Plc " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Place d'"))
            {
                string resteNom = nom.Substring(8); // Enlève "Place d'"
                return "Plc " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Place "))
            {
                string resteNom = nom.Substring(6); // Enlève "Place "
                return "Plc " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Rue des "))
            {
                string resteNom = nom.Substring(8); // Enlève "Rue des "
                return "R " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Rue du "))
            {
                string resteNom = nom.Substring(7); // Enlève "Rue du "
                return "R " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Rue de la "))
            {
                string resteNom = nom.Substring(10); // Enlève "Rue de la "
                return "R " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Rue "))
            {
                string resteNom = nom.Substring(4); // Enlève "Rue "
                return "R " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Gare de "))
            {
                string resteNom = nom.Substring(8); // Enlève "Gare de "
                return "Gare " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Gare du "))
            {
                string resteNom = nom.Substring(8); // Enlève "Gare du "
                return "Gare " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Les "))
            {
                string resteNom = nom.Substring(4); // Enlève "Les "
                return "Les " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("La "))
            {
                string resteNom = nom.Substring(3); // Enlève "La "
                return "La " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Le "))
            {
                string resteNom = nom.Substring(3); // Enlève "Le "
                return "Le " + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            if (nom.StartsWith("Saint-"))
            {
                string resteNom = nom.Substring(6); // Enlève "Saint-"
                return "St-" + resteNom.Substring(0, Math.Min(7, resteNom.Length));
            }
            return nom.Substring(0, Math.Min(7, nom.Length));
        }


        /// <summary>
        /// Dessine une flèche entre deux points.
        /// </summary>
        /// <param name="g">L'objet Graphics utilisé pour dessiner.</param>
        /// <param name="pen">Le stylo utilisé pour dessiner la flèche.</param>
        /// <param name="depart">Le point de départ de la flèche.</param>
        /// <param name="arrivee">Le point d'arrivée de la flèche.</param>
        private void DessinerFleche(Graphics g, Pen pen, PointF depart, PointF arrivee)
        {
            double angle = Math.Atan2(arrivee.Y - depart.Y, arrivee.X - depart.X);
            double flecheSize = 10;

            PointF p1 = new PointF(
                (float)(arrivee.X - flecheSize * Math.Cos(angle - Math.PI / 6)),
                (float)(arrivee.Y - flecheSize * Math.Sin(angle - Math.PI / 6))
            );

            PointF p2 = new PointF(
                (float)(arrivee.X - flecheSize * Math.Cos(angle + Math.PI / 6)),
                (float)(arrivee.Y - flecheSize * Math.Sin(angle + Math.PI / 6))
            );

            g.DrawLine(pen, arrivee, p1);
            g.DrawLine(pen, arrivee, p2);
        }

        /// <summary>
        /// Ajuste le point d'arrivée d'un arc pour dessiner une flèche.
        /// </summary>
        /// <param name="arrivee">Le point d'arrivée initial.</param>
        /// <param name="depart">Le point de départ.</param>
        /// <param name="distance">La distance à reculer.</param>
        /// <returns>Le nouveau point d'arrivée ajusté.</returns>
        private PointF ReculerPoint(PointF arrivee, PointF depart, float distance)
        {
            double angle = Math.Atan2(arrivee.Y - depart.Y, arrivee.X - depart.X);
            return new PointF(
                (float)(arrivee.X - distance * Math.Cos(angle)),
                (float)(arrivee.Y - distance * Math.Sin(angle))
            );
        }

        private void FormMetro_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
