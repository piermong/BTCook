﻿using System;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using projet_final_new;

namespace projet_final_new
{
    public partial class FormRegister : Form
    {
        private string connectionString = "Server=localhost;Database=BTCook;Uid=root;Pwd=root;";


        public FormRegister()
        {
            InitializeComponent();
            TestDatabaseConnection();
        }

        private void FormRegister_Load(object sender, EventArgs e)
        {

        }


        private void inscrirefinal_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();
            string address = txtAddress.Text.Trim();
            string email = txtEmail.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string password = txtmdp.Text.Trim();

            // Vérification des champs obligatoires
            if (!IsValidName(firstName) || !IsValidName(lastName))
            {
                MessageBox.Show("Le prénom et le nom doivent contenir uniquement des lettres et au moins 2 caractères.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Veuillez entrer une adresse e-mail valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidPhone(phone))
            {
                MessageBox.Show("Le numéro de téléphone doit contenir uniquement des chiffres et avoir entre 8 et 15 caractères.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidPassword(password))
            {
                MessageBox.Show("Le mot de passe doit contenir au moins 8 caractères, une majuscule, un chiffre et un caractère spécial.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Vérifier si l'email existe déjà
                    string checkEmailQuery = "SELECT COUNT(*) FROM UTILISATEUR WHERE email = @Email";
                    using (MySqlCommand checkCmd = new MySqlCommand(checkEmailQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@Email", email);
                        int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show("Cet email est déjà utilisé. Veuillez en choisir un autre.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // Insérer l'utilisateur dans la base de données sans régime et réseaux sociaux
                    string query = "INSERT INTO UTILISATEUR (nom, prénom, notation, adresse, email, téléphone, password) " +
                                   "VALUES (@Nom, @Prenom, 0, @Adresse, @Email, @Telephone, @Password)";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Nom", firstName);
                        cmd.Parameters.AddWithValue("@Prenom", lastName);
                        cmd.Parameters.AddWithValue("@Adresse", address);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Telephone", phone);
                        cmd.Parameters.AddWithValue("@Password",password); // Hachage du mot de passe

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Inscription réussie !", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Ouvrir le formulaire de connexion
                            FormLogin loginForm = new FormLogin();
                            loginForm.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Échec de l'inscription.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'inscription : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }





        // Fonction pour valider le nom/prénom (lettres uniquement, min. 2 caractères)
        private bool IsValidName(string name)
        {
            return Regex.IsMatch(name, @"^[A-Za-zÀ-ÖØ-öø-ÿ]{2,}$");
        }

        // Fonction pour valider l'email
        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        // Fonction pour valider le téléphone (8 à 15 chiffres)
        private bool IsValidPhone(string phone)
        {
            return Regex.IsMatch(phone, @"^\d{8,15}$");
        }

        // Fonction pour valider le mot de passe (8 caractères, 1 majuscule, 1 chiffre, 1 caractère spécial)
        private bool IsValidPassword(string password)
        {
            return Regex.IsMatch(password, @"^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$");
        }

        // Fonction pour hacher un mot de passe (SHA256)
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Ouvre un formulaire de connexion
            FormLogin loginForm = new FormLogin();
            loginForm.Show(); // Affiche le formulaire de connexion
            this.Hide(); // Cache Form1
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {

        }


        public bool TestDatabaseConnection()
        {
            string connectionString = "server=localhost;database=BTCook;user=root;password=root;";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    MessageBox.Show("Connexion réussie à la base de données !");
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connexion : " + ex.Message);
                return false;
            }
        }

    }


}

