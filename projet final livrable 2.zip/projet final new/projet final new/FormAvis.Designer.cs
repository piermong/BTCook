﻿namespace projet_final_new
{
    partial class FormAvis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1 = new TextBox();
            btLivrer = new Button();
            label2 = new Label();
            cmbNote = new ComboBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(134, 117);
            label1.Name = "label1";
            label1.Size = new Size(306, 20);
            label1.TabIndex = 0;
            label1.Text = "Laisser un commentaire ou un avi (optionel) :";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.ActiveBorder;
            textBox1.Location = new Point(134, 140);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(510, 27);
            textBox1.TabIndex = 1;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // btLivrer
            // 
            btLivrer.BackColor = Color.Crimson;
            btLivrer.Location = new Point(220, 335);
            btLivrer.Name = "btLivrer";
            btLivrer.Size = new Size(307, 57);
            btLivrer.TabIndex = 2;
            btLivrer.Text = "Confirmer la livraison de la commande";
            btLivrer.UseVisualStyleBackColor = false;
            btLivrer.Click += btLivrer_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(163, 295);
            label2.Name = "label2";
            label2.Size = new Size(461, 20);
            label2.TabIndex = 3;
            label2.Text = "une fois que vous avez bien reçu la commande veuiller la confirmer :";
            // 
            // cmbNote
            // 
            cmbNote.FormattingEnabled = true;
            cmbNote.Location = new Point(429, 226);
            cmbNote.Name = "cmbNote";
            cmbNote.Size = new Size(58, 28);
            cmbNote.TabIndex = 4;
            cmbNote.SelectedIndexChanged += cmbNote_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(257, 229);
            label3.Name = "label3";
            label3.Size = new Size(157, 20);
            label3.TabIndex = 5;
            label3.Text = "mettre une note sur 5 :";
            label3.Click += label3_Click;
            // 
            // FormAvis
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(cmbNote);
            Controls.Add(label2);
            Controls.Add(btLivrer);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "FormAvis";
            Text = "FormAvis";
            Load += FormAvis_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private Button btLivrer;
        private Label label2;
        private ComboBox cmbNote;
        private Label label3;
    }
}