﻿namespace projet_final_new
{
    partial class FormChoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (!disposing || components == null)
            {
            }
            else
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCuisinier = new Button();
            buttonClient = new Button();
            buttonMenu = new Button();
            SuspendLayout();
            // 
            // buttonCuisinier
            // 
            buttonCuisinier.BackColor = Color.DarkCyan;
            buttonCuisinier.Location = new Point(12, 12);
            buttonCuisinier.Name = "buttonCuisinier";
            buttonCuisinier.Size = new Size(378, 300);
            buttonCuisinier.TabIndex = 0;
            buttonCuisinier.Text = "Cuisinier";
            buttonCuisinier.UseVisualStyleBackColor = false;
            buttonCuisinier.Click += buttonCuisinier_Click;
            // 
            // buttonClient
            // 
            buttonClient.BackColor = Color.DarkSeaGreen;
            buttonClient.Location = new Point(410, 12);
            buttonClient.Name = "buttonClient";
            buttonClient.Size = new Size(378, 300);
            buttonClient.TabIndex = 1;
            buttonClient.Text = "Client";
            buttonClient.UseVisualStyleBackColor = false;
            buttonClient.Click += buttonClient_Click;
            // 
            // buttonMenu
            // 
            buttonMenu.Location = new Point(331, 366);
            buttonMenu.Name = "buttonMenu";
            buttonMenu.Size = new Size(136, 29);
            buttonMenu.TabIndex = 2;
            buttonMenu.Text = "Retour au menu";
            buttonMenu.UseVisualStyleBackColor = true;
            buttonMenu.Click += buttonMenu_Click;
            // 
            // FormChoice
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonMenu);
            Controls.Add(buttonClient);
            Controls.Add(buttonCuisinier);
            Name = "FormChoice";
            Text = "FormChoice";
            Load += FormChoice_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button buttonCuisinier;
        private Button buttonClient;
        private Button buttonMenu;
    }
}