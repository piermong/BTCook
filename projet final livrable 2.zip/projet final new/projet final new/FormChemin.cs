﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace projet_final_new
{
    public partial class FormChemin : Form
    {
        private Carte _carte;
        private List<string> _stationsPlats;
        private string _stationClient;
        private int _matriculeCommande;

        public FormChemin(Carte carte, List<string> stationsPlats, string stationClient, int matriculeCommande)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;

            _carte = carte;
            _stationsPlats = stationsPlats;
            _stationClient = stationClient;
            _matriculeCommande = matriculeCommande;
            carte.AfficheMessage = message => label1.Text += message + Environment.NewLine;
        }

        private void FormChemin_Load(object sender, EventArgs e)
        {
            foreach (var stationPlat in _stationsPlats)
            {
                // Calcul des trois chemins
                var cheminDijkstra = _carte.Dijkstra(stationPlat, _stationClient);
                var cheminBellman = _carte.BellmanFord(stationPlat, _stationClient);
                var cheminFloydWarshall = _carte.AlgoFloydWarshall(stationPlat, _stationClient);

                // Comparaison des poids des chemins
                double poidsDijkstra = cheminDijkstra[^1].Poids;
                double poidsBellman = cheminBellman[^1].Poids;
                double poidsFloydWarshall = cheminFloydWarshall[^1].Poids;

                // Mise à jour du label avec les trois chemins
                label1.Invoke(new Action(() =>
                {
                    label1.Text += $"Chemins de {stationPlat} à {_stationClient} :\n\n";

                    // Affichage de tous les chemins
                    label1.Text += $"Dijkstra : \n";
                    label1.Text += string.Join(" -> ", cheminDijkstra.Select(st => st.Nom)) + $"\nPoids : {poidsDijkstra}\n\n";

                    label1.Text += $"Bellman-Ford : \n";
                    label1.Text += string.Join(" -> ", cheminBellman.Select(st => st.Nom)) + $"\nPoids : {poidsBellman}\n\n";

                    label1.Text += $"Floyd-Warshall : \n";
                    label1.Text += string.Join(" -> ", cheminFloydWarshall.Select(st => st.Nom)) + $"\nPoids : {poidsFloydWarshall}\n\n";

                    int dureeEstimee = 0;

                    if (poidsDijkstra <= poidsBellman && poidsDijkstra <= poidsFloydWarshall)
                    {
                        label1.Text += $"Le chemin optimal est celui trouvé par Dijkstra.\n\n";
                        _carte.AfficherCheminOptimal(cheminDijkstra);
                        dureeEstimee = (int)poidsDijkstra;
                    }
                    else if (poidsBellman <= poidsDijkstra && poidsBellman <= poidsFloydWarshall)
                    {
                        label1.Text += $"Le chemin optimal est celui trouvé par Bellman-Ford.\n\n";
                        _carte.AfficherCheminOptimal(cheminBellman);
                        dureeEstimee = (int)poidsBellman;
                    }
                    else
                    {
                        label1.Text += $"Le chemin optimal est celui trouvé par Floyd-Warshall.\n\n";
                        _carte.AfficherCheminOptimal(cheminFloydWarshall);
                        dureeEstimee = (int)poidsFloydWarshall;
                    }
                    
                    // Appel à la méthode pour mettre à jour dans la base de données
                    UpdateTempsTrajetCommande(_matriculeCommande, dureeEstimee);
                }));
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Tu peux le laisser vide, sauf si tu veux faire quelque chose au clic
        }

        // Bouton pour revenir au FormMetro
        private void buttonRetourMetro_Click(object sender, EventArgs e)
        {
            // Masquer le FormChemin actuel et ouvrir FormMetro
            this.Close(); // Masquer FormChemin
            FormMetro formMetro = new FormMetro(_stationsPlats, _stationClient, _matriculeCommande); // Créer une nouvelle instance de FormMetro
            formMetro.Show(); // Afficher FormMetro
        }

        // Bouton pour ouvrir FormAvis
        private void buttonOuvrirAvis_Click(object sender, EventArgs e)
        {
            // Ferme FormChemin et ouvre FormAvis
            this.Close();
            FormAvis formAvis = new FormAvis(_matriculeCommande);  // Créer une nouvelle instance de FormAvis
            formAvis.Show();
        }

        private void UpdateTempsTrajetCommande(int matriculeCommande, int tempsEnMinutes)
        {
            // Convertir la durée en minutes en format 'HH:MM:SS'
            TimeSpan timeSpan = TimeSpan.FromMinutes(tempsEnMinutes);
            string duréeEstimée = timeSpan.ToString(@"hh\:mm\:ss");

            string query = "UPDATE COMMANDE SET duréeEstimée = @Temps WHERE matriculeCommande = @Matricule";

            try
            {
                string connectionString = "Server=localhost;Database=BTCook;User ID=root;Password=root";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Temps", duréeEstimée); // Passer le temps formaté
                        command.Parameters.AddWithValue("@Matricule", matriculeCommande);

                        command.ExecuteNonQuery();
                    }
                }

                //MessageBox.Show("Durée estimée enregistrée dans la commande !");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la mise à jour de la durée : {ex.Message}");
            }
        }


    }
}
