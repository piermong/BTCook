﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace projet_final_new
{
    public partial class FormChoice : Form
    {
        public FormChoice()
        {
            InitializeComponent();
        }

        private void buttonClient_Click(object sender, EventArgs e)
        {
            string email = FormLogin.EmailUtilisateur;  // Récupère l'email de l'utilisateur connecté

            // Insère l'utilisateur comme client
            InsertUserRole(email, "client");

            // Ouvre FormOrder (page du client)
            FormOrder formOrder = new FormOrder();
            formOrder.Show();
            this.Hide(); // Cache FormChoice
        }

        private void buttonCuisinier_Click(object sender, EventArgs e)
        {
            string email = FormLogin.EmailUtilisateur;  // Récupère l'email de l'utilisateur connecté

            // Insère l'utilisateur comme cuisinier
            InsertUserRole(email, "cuisinier");

            // Ouvre FormChef (page du cuisinier)
            FormChef formChef = new FormChef();
            formChef.Show();
            this.Hide(); // Cache FormChoice
        }

        private void InsertUserRole(string email, string role)
        {
            using (MySqlConnection conn = new MySqlConnection("server=localhost;database=BTCook;uid=root;pwd=root"))
            {
                try
                {
                    conn.Open();

                    // Récupère le matriculeUtilisateur (id) de l'utilisateur à partir de l'email
                    string getUserIdQuery = "SELECT matriculeUtilisateur FROM UTILISATEUR WHERE email = @Email";
                    MySqlCommand getUserIdCmd = new MySqlCommand(getUserIdQuery, conn);
                    getUserIdCmd.Parameters.AddWithValue("@Email", email);
                    object userIdObj = getUserIdCmd.ExecuteScalar();

                    if (userIdObj != null)
                    {
                        long userId = Convert.ToInt64(userIdObj);

                        // Insère l'utilisateur dans la bonne table en fonction de son rôle
                        if (role == "client")
                        {
                            string insertClientQuery = "INSERT INTO CLIENT (matriculeUtilisateur) VALUES (@UserId)";
                            MySqlCommand insertClientCmd = new MySqlCommand(insertClientQuery, conn);
                            insertClientCmd.Parameters.AddWithValue("@UserId", userId);
                            insertClientCmd.ExecuteNonQuery();
                        }
                        else if (role == "cuisinier")
                        {
                            string insertChefQuery = "INSERT INTO CUISINIER (matriculeUtilisateur) VALUES (@UserId)";
                            MySqlCommand insertChefCmd = new MySqlCommand(insertChefQuery, conn);
                            insertChefCmd.Parameters.AddWithValue("@UserId", userId);
                            insertChefCmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'insertion : " + ex.Message);
                }
            }
        }


        private void buttonMenu_Click(object sender, EventArgs e)
        {
            Form1 mainMenu = new Form1(); // Retour au menu principal
            mainMenu.Show();
            this.Hide(); // Cache le formulaire actuel
        }

        private void FormChoice_Load(object sender, EventArgs e)
        {
          
        }
    }
}
