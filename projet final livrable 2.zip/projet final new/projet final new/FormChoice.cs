﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace projet_final_new
{
    public partial class FormChoice : Form
    {
        public FormChoice()
        {
            InitializeComponent();
        }

        private void FormChoice_Load(object sender, EventArgs e)
        {
            // Rien ici pour le moment
        }

        private void buttonClient_Click(object sender, EventArgs e)
        {
            string email = FormLogin.EmailUtilisateur;
            InsertUserRole(email, "client");

            new FormOrder().Show();
            this.Hide();
        }

        private void buttonCuisinier_Click(object sender, EventArgs e)
        {
            string email = FormLogin.EmailUtilisateur;
            InsertUserRole(email, "cuisinier");

            new FormChef().Show();
            this.Hide();
        }

        private void InsertUserRole(string email, string role)
        {
            string connStr = "server=localhost;database=BTCook;uid=root;pwd=root";

            using (var conn = new MySqlConnection(connStr))
            {
                try
                {
                    conn.Open();

                    // Récupère l'ID utilisateur
                    string getIdQuery = "SELECT matriculeUtilisateur FROM UTILISATEUR WHERE email = @Email";
                    var getIdCmd = new MySqlCommand(getIdQuery, conn);
                    getIdCmd.Parameters.AddWithValue("@Email", email);

                    object userIdObj = getIdCmd.ExecuteScalar();

                    if (userIdObj != null)
                    {
                        long userId = Convert.ToInt64(userIdObj);

                        // Insert en fonction du rôle
                        string insertQuery = role == "client"
                            ? "INSERT INTO CLIENT (matriculeUtilisateur) VALUES (@UserId)"
                            : "INSERT INTO CUISINIER (matriculeUtilisateur) VALUES (@UserId)";

                        var insertCmd = new MySqlCommand(insertQuery, conn);
                        insertCmd.Parameters.AddWithValue("@UserId", userId);
                        insertCmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    //MessageBox.Show("Erreur lors de l'insertion : " + ex.Message);
                }
            }
        }

        private void buttonMenu_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }
    }
}

