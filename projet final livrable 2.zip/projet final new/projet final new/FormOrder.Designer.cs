﻿namespace projet_final_new
{
    partial class FormOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvPlats = new DataGridView();
            dgvPanier = new DataGridView();
            btnAjouterAuPanier = new Button();
            btnValiderCommande = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvPlats).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPanier).BeginInit();
            SuspendLayout();
            // 
            // dgvPlats
            // 
            dgvPlats.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPlats.Location = new Point(10, 9);
            dgvPlats.Margin = new Padding(3, 2, 3, 2);
            dgvPlats.Name = "dgvPlats";
            dgvPlats.RowHeadersWidth = 51;
            dgvPlats.Size = new Size(391, 208);
            dgvPlats.TabIndex = 0;
            dgvPlats.CellContentClick += dgvPlats_CellContentClick;
            // 
            // dgvPanier
            // 
            dgvPanier.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPanier.Location = new Point(407, 9);
            dgvPanier.Margin = new Padding(3, 2, 3, 2);
            dgvPanier.Name = "dgvPanier";
            dgvPanier.RowHeadersWidth = 51;
            dgvPanier.Size = new Size(283, 208);
            dgvPanier.TabIndex = 1;
            dgvPanier.CellContentClick += dgvPanier_CellContentClick;
            // 
            // btnAjouterAuPanier
            // 
            btnAjouterAuPanier.Location = new Point(125, 258);
            btnAjouterAuPanier.Margin = new Padding(3, 2, 3, 2);
            btnAjouterAuPanier.Name = "btnAjouterAuPanier";
            btnAjouterAuPanier.Size = new Size(152, 22);
            btnAjouterAuPanier.TabIndex = 2;
            btnAjouterAuPanier.Text = "Ajouter au panier";
            btnAjouterAuPanier.UseVisualStyleBackColor = true;
            btnAjouterAuPanier.Click += btnAjouterAuPanier_Click;
            // 
            // btnValiderCommande
            // 
            btnValiderCommande.Location = new Point(496, 244);
            btnValiderCommande.Margin = new Padding(3, 2, 3, 2);
            btnValiderCommande.Name = "btnValiderCommande";
            btnValiderCommande.Size = new Size(122, 43);
            btnValiderCommande.TabIndex = 3;
            btnValiderCommande.Text = "Valider la commande";
            btnValiderCommande.UseVisualStyleBackColor = true;
            btnValiderCommande.Click += btnValiderCommande_Click;
            // 
            // FormOrder
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(btnValiderCommande);
            Controls.Add(btnAjouterAuPanier);
            Controls.Add(dgvPanier);
            Controls.Add(dgvPlats);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FormOrder";
            Text = "FormOrder";
            Load += FormOrder_Load;
            ((System.ComponentModel.ISupportInitialize)dgvPlats).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPanier).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPlats;
        private System.Windows.Forms.DataGridView dgvPanier;
        private Button btnAjouterAuPanier;
        private Button btnValiderCommande;
    }
}