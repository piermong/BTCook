﻿namespace projet_final_new
{
    partial class FormDelivery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            btnCommandefinal = new Button();
            dgvResumer = new DataGridView();
            lblTotal = new Label();
            cmbMetro = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dgvResumer).BeginInit();
            SuspendLayout();
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.ActiveBorder;
            textBox2.Location = new Point(350, 160);
            textBox2.Margin = new Padding(3, 2, 3, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(325, 23);
            textBox2.TabIndex = 1;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(350, 70);
            label1.Name = "label1";
            label1.Size = new Size(294, 15);
            label1.TabIndex = 2;
            label1.Text = "Entrer la station de Metro la plus proche de chez vous :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(350, 143);
            label2.Name = "label2";
            label2.Size = new Size(190, 15);
            label2.TabIndex = 3;
            label2.Text = "Message pour le livreur (optionel) :";
            // 
            // btnCommandefinal
            // 
            btnCommandefinal.BackColor = Color.Crimson;
            btnCommandefinal.Location = new Point(467, 218);
            btnCommandefinal.Margin = new Padding(3, 2, 3, 2);
            btnCommandefinal.Name = "btnCommandefinal";
            btnCommandefinal.Size = new Size(99, 22);
            btnCommandefinal.TabIndex = 4;
            btnCommandefinal.Text = "Commander";
            btnCommandefinal.UseVisualStyleBackColor = false;
            btnCommandefinal.Click += btnCommandefinal_Click;
            // 
            // dgvResumer
            // 
            dgvResumer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvResumer.Location = new Point(12, 12);
            dgvResumer.Name = "dgvResumer";
            dgvResumer.Size = new Size(314, 286);
            dgvResumer.TabIndex = 5;
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Arial", 12F, FontStyle.Bold);
            lblTotal.Location = new Point(12, 301);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(82, 19);
            lblTotal.TabIndex = 0;
            lblTotal.Text = "Total : 0 €";
            lblTotal.Click += lblTotal_Click;
            // 
            // cmbMetro
            // 
            cmbMetro.FormattingEnabled = true;
            cmbMetro.Items.AddRange(new object[] { "Abbesses", "Alésia", "Alexandre Dumas", "Alma - Marceau", "Anvers", "Argentine", "Arts et Métiers", "Assemblée Nationale", "Avenue Emile Zola", "Avron", "Balard", "Barbès - Rochechouart", "Bastille", "Bel-Air", "Belleville", "Bercy", "Bibliothèque François Mitterrand", "Bir-Hakeim", "Blanche", "Boissière", "Bolivar", "Bonne Nouvelle", "Botzaris", "Boucicaut", "Bourse", "Bréguet-Sabin", "Brochant", "Buttes Chaumont", "Buzenval", "Cadet", "Cambronne", "Campo-Formio", "Cardinal Lemoine", "Censier - Daubenton", "Champs-Elysées - Clemenceau", "Chardon Lagache", "Charles de Gaulle - Etoile", "Charles Michels", "Charonne", "Château de Vincennes", "Château d'Eau", "Château Landon", "Château Rouge", "Châtelet", "Chaussée d'Antin - La Fayette", "Chemin Vert", "Chevaleret", "Cité", "Cluny - La Sorbonne", "Colonel Fabien", "Commerce", "Concorde", "Convention", "Corentin Cariou", "Corvisart", "Cour Saint-Emilion", "Courcelles", "Couronnes", "Crimée", "Danube", "Daumesnil", "Denfert-Rochereau", "Dugommier", "Dupleix", "Duroc", "Ecole Militaire", "Edgar Quinet", "Eglise d'Auteuil", "Etienne Marcel", "Europe", "Exelmans", "Faidherbe - Chaligny", "Falguière", "Félix Faure", "Filles du Calvaire", "Franklin D. Roosevelt", "Gaîté", "Gambetta", "Gare d'Austerlitz", "Gare de l'Est", "Gare de Lyon", "Gare du Nord", "George V", "Glacière", "Goncourt", "Grands Boulevards", "Guy Môquet", "Havre-Caumartin", "Hôtel de Ville", "Iéna", "Invalides", "Jacques Bonsergent", "Jasmin", "Jaurès", "Javel - André Citroën", "Jourdain", "Jules Joffrin", "Jussieu", "Kléber", "La Chapelle", "La Fourche", "La Motte-Picquet - Grenelle", "La Muette", "La Tour-Maubourg", "Lamarck - Caulaincourt", "Laumière", "Le Peletier", "Ledru-Rollin", "Les Gobelins", "Les Halles", "Liège", "Louis Blanc", "Lourmel", "Louvre - Rivoli", "Mabillon", "Madeleine", "Maison Blanche", "Malesherbes", "Maraîchers", "Marcadet - Poissonniers", "Marx Dormoy", "Maubert - Mutualité", "Ménilmontant", "Michel Bizot", "Michel-Ange - Auteuil", "Michel-Ange - Molitor", "Mirabeau", "Miromesnil", "Monceau", "Montgallet", "Montparnasse Bienvenue", "Mouton-Duvernet", "Nation", "Nationale", "Notre-Dame des Champs", "Notre-Dame-de-Lorette", "Oberkampf", "Odéon", "Olympiades", "Opéra", "Ourcq", "Palais Royal - Musée du Louvre", "Parmentier", "Passy", "Pasteur", "Pelleport", "Père Lachaise", "Pereire", "Pernety", "Philippe Auguste", "Picpus", "Pigalle", "Place de Clichy", "Place des Fêtes", "Place d'Italie", "Place Monge", "Plaisance", "Poissonnière", "Pont Cardinet", "Pont Marie (Cité des Arts)", "Pont Neuf", "Porte Dauphine", "Porte d'Auteuil", "Porte de Bagnolet", "Porte de Champerret", "Porte de Charenton", "Porte de Choisy", "Porte de Clichy", "Porte de Clignancourt", "Porte de la Chapelle", "Porte de la Villette", "Porte de Montreuil", "Porte de Pantin", "Porte de Saint-Cloud", "Porte de Saint-Ouen", "Porte de Vanves", "Porte de Versailles", "Porte de Vincennes", "Porte des Lilas", "Porte d'Italie", "Porte d'Ivry", "Porte Dorée", "Porte d'Orléans", "Porte Maillot", "Pré-Saint-Gervais", "Pyramides", "Pyrénées", "Quai de la Gare", "Quai de la Rapée", "Quatre Septembre", "Rambuteau", "Ranelagh", "Raspail", "Réaumur - Sébastopol", "Rennes", "République", "Reuilly - Diderot", "Richard-Lenoir", "Richelieu - Drouot", "Riquet", "Rome", "Rue de la Pompe", "Rue des Boulets", "Rue du Bac", "Rue Saint-Maur", "Saint-Ambroise", "Saint-Augustin", "Saint-Fargeau", "Saint-François-Xavier", "Saint-Georges", "Saint-Germain-des-Prés", "Saint-Jacques", "Saint-Lazare", "Saint-Marcel", "Saint-Michel", "Saint-Paul (Le Marais)", "Saint-Philippe du Roule", "Saint-Placide", "Saint-Sébastien - Froissart", "Saint-Sulpice", "Ségur", "Sentier", "Sèvres - Babylone", "Sèvres-Lecourbe", "Simplon", "Solférino", "Stalingrad", "Strasbourg - Saint-Denis", "Sully - Morland", "Télégraphe", "Temple", "Ternes", "Tolbiac", "Trinité - d'Estienne d'Orves", "Trocadéro", "Tuileries", "Vaneau", "Varenne", "Vaugirard", "Vavin", "Victor Hugo", "Villiers", "Volontaires", "Voltaire", "Wagram" });
            cmbMetro.Location = new Point(350, 88);
            cmbMetro.Name = "cmbMetro";
            cmbMetro.Size = new Size(325, 23);
            cmbMetro.TabIndex = 6;
            // 
            // FormDelivery
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(cmbMetro);
            Controls.Add(lblTotal);
            Controls.Add(dgvResumer);
            Controls.Add(btnCommandefinal);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FormDelivery";
            Text = "FormDelivery";
            Load += FormDelivery_Load;
            ((System.ComponentModel.ISupportInitialize)dgvResumer).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private Button btnCommandefinal;
        private DataGridView dgvResumer;
        private Label lblTotal;
        private ComboBox cmbMetro;
    }
}