﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Data.SqlClient; // Assure-toi d'utiliser le bon namespace pour MySQL
using System.Windows.Forms;

namespace projet_final_new
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            // Code d'initialisation si nécessaire
        }

        public static string EmailUtilisateur;  // Champ pour stocker l'email

        private void button1_Click(object sender, EventArgs e)
        {
            string email = textBoxEmail.Text;
            string password = textBoxPassword.Text;

            using (MySqlConnection conn = new MySqlConnection("server=localhost;database=BTCook;uid=root;pwd=root"))
            {
                try
                {
                    conn.Open();

                    string query = "SELECT COUNT(*) FROM UTILISATEUR WHERE email = @Email AND password = @Password";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Password", password);

                    int userExists = Convert.ToInt32(cmd.ExecuteScalar());

                    if (userExists > 0)
                    {
                        // Connexion réussie, stocke l'email et ouvre le choix de rôle
                        EmailUtilisateur = email;  // Stocke l'email
                        MessageBox.Show("Connexion réussie!");

                        FormChoice choiceForm = new FormChoice();
                        choiceForm.Show();
                        this.Hide(); // Cache FormLogin
                    }
                    else
                    {
                        MessageBox.Show("Email ou mot de passe incorrect!", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur de connexion à la base de données: " + ex.Message);
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            // Ouvre le formulaire d'inscription
            FormRegister registerForm = new FormRegister();
            registerForm.Show();
            this.Hide(); // Cache FormLogin
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Code pour gérer le changement de texte dans le champ Email (si nécessaire)
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // Code pour gérer le changement de texte dans le champ Mot de passe (si nécessaire)
        }
    }
}
