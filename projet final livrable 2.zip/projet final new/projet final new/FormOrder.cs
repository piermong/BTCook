﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace projet_final_new
{
    public partial class FormOrder : Form
    {
        // Connexion à la base de données
        private MySqlConnection connection;

        // Liste des plats (panier)
        private List<Plat> panier;

        // DataTable pour gérer l'affichage dans le DataGridView
        private DataTable dtPanier;

        public FormOrder()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            panier = new List<Plat>();
            dtPanier = new DataTable();
            LoadPlats();
            InitializePanierDataTable();
        }

        // Initialiser la connexion à la base de données MySQL
        private void InitializeDatabaseConnection()
        {
            string connectionString = "Server=localhost;Database=BTCook;Uid=root;Pwd=root;";
            connection = new MySqlConnection(connectionString);
        }

        // Charger les plats depuis la base de données
        private void LoadPlats()
        {
            try
            {
                connection.Open();
                string query = "SELECT nom, prix FROM plat"; // Récupérer nom et prix
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Afficher les plats dans le DataGridView
                dgvPlats.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        // Initialiser la structure du DataTable pour le panier
        private void InitializePanierDataTable()
        {
            dtPanier.Columns.Add("Nom", typeof(string));
            dtPanier.Columns.Add("Prix", typeof(decimal));

            // Ajouter une ligne vide pour le total
            dtPanier.Rows.Add("Total : ", 0);
            dgvPanier.DataSource = dtPanier;
        }

        // Ajouter un plat au panier
        private void btnAjouterAuPanier_Click(object sender, EventArgs e)
        {
            if (dgvPlats.SelectedRows.Count > 0)
            {
                // Récupérer le plat sélectionné
                string nom = dgvPlats.SelectedRows[0].Cells[0].Value.ToString();
                decimal prix = Convert.ToDecimal(dgvPlats.SelectedRows[0].Cells[1].Value);

                // Ajouter le plat au panier
                panier.Add(new Plat { Nom = nom, Prix = prix });

                // Ajouter le plat dans le DataTable du panier
                dtPanier.Rows.InsertAt(dtPanier.NewRow(), dtPanier.Rows.Count - 1);
                dtPanier.Rows[dtPanier.Rows.Count - 2]["Nom"] = nom;
                dtPanier.Rows[dtPanier.Rows.Count - 2]["Prix"] = prix;

                // Mettre à jour le total
                AfficherPrixTotal();
            }
            else
            {
                MessageBox.Show("Sélectionne un plat à ajouter !");
            }
        }

        // Afficher le prix total dans la dernière ligne
        private void AfficherPrixTotal()
        {
            decimal total = 0;
            foreach (Plat plat in panier)
            {
                total += plat.Prix;
            }

            // Mettre à jour le total dans la dernière ligne du DataTable
            dtPanier.Rows[dtPanier.Rows.Count - 1]["Prix"] = total;
        }

        // Valider la commande
        private void btnValiderCommande_Click(object sender, EventArgs e)
        {
            if (panier.Count > 0)
            {
                FormDelivery formDelivery = new FormDelivery(new List<Plat>(panier)); // Envoie la liste
                formDelivery.ShowDialog(); // Ouvre la nouvelle fenêtre
                this.Close();
            }
            else
            {
                MessageBox.Show("Ton panier est vide !");
            }
        }

        // Quand une cellule de dgvPlats est cliquée
        private void dgvPlats_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Tu peux ajouter une action si tu veux que quelque chose se passe
            // lorsque l'utilisateur clique sur une cellule de dgvPlats
            // Exemple : afficher un message avec le nom du plat
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPlats.Rows[e.RowIndex];
                string platNom = row.Cells["nom"].Value.ToString();
                MessageBox.Show("Tu as cliqué sur le plat : " + platNom);
            }
        }

        // Quand une cellule de dgvPanier est cliquée
        private void dgvPanier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Tu peux ajouter une action si tu veux que quelque chose se passe
            // lorsque l'utilisateur clique sur une cellule de dgvPanier
            // Exemple : afficher un message avec le nom du plat dans le panier
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPanier.Rows[e.RowIndex];
                string platNom = row.Cells["Nom"].Value.ToString();
                MessageBox.Show("Plat dans le panier : " + platNom);
            }
        }

        private void FormOrder_Load(object sender, EventArgs e)
        {

        }
    }

    // Classe Plat simplifiée (sans ID)
    public class Plat
    {
        public string Nom { get; set; }
        public decimal Prix { get; set; }
    }
}




