﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace projet_final_new
{
    public partial class FormOrder : Form
    {
        private MySqlConnection connection;        // Connexion à MySQL
        private List<Plat> panier;                // Liste pour stocker les plats choisis
        private DataTable dtPanier;               // Structure pour afficher le panier

        public FormOrder()
        {
            InitializeComponent();
            InitConnexionBDD();
            panier = new List<Plat>();
            dtPanier = new DataTable();
            ChargerPlatsBDD();
            InitStructurePanier();
        }

        // Connexion MySQL
        private void InitConnexionBDD()
        {
            string connectionString = "Server=localhost;Database=BTCook;Uid=root;Pwd=root;";
            connection = new MySqlConnection(connectionString);
        }

        // Charge les plats depuis la BDD
        private void ChargerPlatsBDD()
        {
            try
            {
                connection.Open();

                string query = "SELECT nom, prix FROM plat";
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                DataTable tablePlats = new DataTable();
                adapter.Fill(tablePlats);

                dgvPlats.DataSource = tablePlats;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        // Initialise les colonnes du DataGridView du panier
        private void InitStructurePanier()
        {
            dtPanier.Columns.Add("Nom", typeof(string));
            dtPanier.Columns.Add("Prix", typeof(decimal));

            // Ligne "Total"
            dtPanier.Rows.Add("Total :", 0);
            dgvPanier.DataSource = dtPanier;
        }

        // Bouton "Ajouter au panier"
        private void btnAjouterAuPanier_Click(object sender, EventArgs e)
        {
            if (dgvPlats.SelectedRows.Count > 0)
            {
                string nom = dgvPlats.SelectedRows[0].Cells[0].Value.ToString();
                decimal prix = Convert.ToDecimal(dgvPlats.SelectedRows[0].Cells[1].Value);

                panier.Add(new Plat { Nom = nom, Prix = prix });

                dtPanier.Rows.InsertAt(dtPanier.NewRow(), dtPanier.Rows.Count - 1);
                dtPanier.Rows[dtPanier.Rows.Count - 2]["Nom"] = nom;
                dtPanier.Rows[dtPanier.Rows.Count - 2]["Prix"] = prix;

                CalculerTotal();
            }
            else
            {
                MessageBox.Show("Sélectionne un plat à ajouter !");
            }
        }

        // Calcule le total des prix dans le panier
        private void CalculerTotal()
        {
            decimal total = 0;

            foreach (Plat plat in panier)
            {
                total += plat.Prix;
            }

            dtPanier.Rows[dtPanier.Rows.Count - 1]["Prix"] = total;
        }

        // Bouton "Valider commande"
        private void btnValiderCommande_Click(object sender, EventArgs e)
        {
            if (panier.Count > 0)
            {
                FormDelivery formDelivery = new FormDelivery(new List<Plat>(panier));
                formDelivery.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Ton panier est vide !");
            }
        }

        // Clique dans dgvPlats
        private void dgvPlats_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string platNom = dgvPlats.Rows[e.RowIndex].Cells["nom"].Value.ToString();
                MessageBox.Show("Tu as cliqué sur le plat : " + platNom);
            }
        }

        // Clique dans dgvPanier
        private void dgvPanier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string platNom = dgvPanier.Rows[e.RowIndex].Cells["Nom"].Value.ToString();
                MessageBox.Show("Plat dans le panier : " + platNom);
            }
        }

        // Load du formulaire
        private void FormOrder_Load(object sender, EventArgs e)
        {
            // Tu peux ajouter des trucs à l’ouverture si tu veux
        }
    }

    // Classe Plat (juste Nom et Prix)
    public class Plat
    {
        public string Nom { get; set; }
        public decimal Prix { get; set; }
    }
}
