﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace projet_final_new
{
    public partial class FormAvis : Form
    {
        private int _matriculeCommande;

        // Le constructeur prend le matricule de la commande et l'assigne à la variable
        public FormAvis(int matriculeCommande)
        {
            InitializeComponent();
            _matriculeCommande = matriculeCommande; // On garde le matricule de la commande pour l'utiliser plus tard
        }

        // Cette méthode se lance lorsque le formulaire est chargé
        private void FormAvis_Load(object sender, EventArgs e)
        {
            // Ajout des notes dans le ComboBox (de 0 à 5)
            for (int i = 0; i <= 5; i++)
            {
                cmbNote.Items.Add(i); // On ajoute les notes dans le ComboBox
            }

            cmbNote.SelectedIndex = 5; // La note par défaut est 5
        }

        // Cette méthode se lance quand on clique sur le bouton "Livrer"
        private void btLivrer_Click(object sender, EventArgs e)
        {
            // Si l'utilisateur n'a pas sélectionné de note, on affiche un message d'erreur
            if (cmbNote.SelectedItem == null)
            {
                MessageBox.Show("Merci de sélectionner une note !");
                return;
            }

            int note = Convert.ToInt32(cmbNote.SelectedItem); // On récupère la note sélectionnée
            string commentaire = textBox1.Text; // On récupère le commentaire de l'utilisateur

            try
            {
                // Connexion à la base de données
                string connectionString = "Server=localhost;Database=BTCook;User ID=root;Password=root";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open(); // On ouvre la connexion à la base de données

                    // 1. Insertion de l'avis dans la table AVIS
                    string insertAvisQuery = "INSERT INTO AVIS (note, commentaire) VALUES (@note, @commentaire)";
                    using (var insertCmd = new MySqlCommand(insertAvisQuery, connection))
                    {
                        insertCmd.Parameters.AddWithValue("@note", note); // On passe la note
                        insertCmd.Parameters.AddWithValue("@commentaire", commentaire); // On passe le commentaire
                        insertCmd.ExecuteNonQuery(); // Exécution de la commande d'insertion
                    }

                    // 2. Récupération du matricule du dernier avis inséré
                    long lastInsertedId = GetLastInsertId(connection);

                    // 3. Mise à jour de la commande pour associer l'avis et changer son état
                    string updateCommandeQuery = "UPDATE COMMANDE SET matriculeAvis = @matAvis, etat = 'livrée' WHERE matriculeCommande = @matCommande";
                    using (var updateCmd = new MySqlCommand(updateCommandeQuery, connection))
                    {
                        updateCmd.Parameters.AddWithValue("@matAvis", lastInsertedId); // On passe le matricule de l'avis
                        updateCmd.Parameters.AddWithValue("@matCommande", _matriculeCommande); // On passe le matricule de la commande
                        updateCmd.ExecuteNonQuery(); // Exécution de la commande de mise à jour
                    }
                }

                // Message pour indiquer que l'avis a été enregistré et la commande est livrée
                MessageBox.Show("Avis enregistré et commande marquée comme livrée !");
                this.Close(); // On ferme le FormAvis
                Application.Exit(); // On ferme tous les autres formulaires aussi
            }
            catch (Exception ex)
            {
                // En cas d'erreur, on affiche un message avec l'erreur
                MessageBox.Show("Erreur lors de l'enregistrement de l'avis : " + ex.Message);
            }
        }

        // Méthode pour récupérer le dernier ID inséré dans la base (celui de l'avis)
        private long GetLastInsertId(MySqlConnection connection)
        {
            using (var cmd = new MySqlCommand("SELECT LAST_INSERT_ID()", connection))
            {
                // On exécute la commande et on retourne l'ID du dernier avis inséré
                return Convert.ToInt64(cmd.ExecuteScalar());
            }
        }

        // Ces méthodes sont là pour gérer les événements mais ne sont pas utilisées
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void cmbNote_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}
