﻿using Org.BouncyCastle.Asn1.Crmf;
using static System.Net.Mime.MediaTypeNames;
using System.Drawing.Printing;
using System.Xml.Linq;

namespace projet_final_new
{
    partial class FormRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            inscrirefinal = new System.Windows.Forms.Button();
            txtFirstName = new System.Windows.Forms.TextBox();
            txtLastName = new System.Windows.Forms.TextBox();
            txtAddress = new System.Windows.Forms.TextBox();
            txtPhone = new System.Windows.Forms.TextBox();
            txtEmail = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            txtmdp = new System.Windows.Forms.TextBox();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            btnLogin = new System.Windows.Forms.Button();
            btnLogin2 = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // inscrirefinal
            // 
            inscrirefinal.BackColor = System.Drawing.Color.Crimson;
            inscrirefinal.Location = new System.Drawing.Point(298, 201);
            inscrirefinal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            inscrirefinal.Name = "inscrirefinal";
            inscrirefinal.Size = new System.Drawing.Size(82, 22);
            inscrirefinal.TabIndex = 0;
            inscrirefinal.Text = "S'inscrire";
            inscrirefinal.UseVisualStyleBackColor = false;
            inscrirefinal.Click += inscrirefinal_Click;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new System.Drawing.Point(286, 41);
            txtFirstName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new System.Drawing.Size(110, 23);
            txtFirstName.TabIndex = 1;
            // 
            // txtLastName
            // 
            txtLastName.Location = new System.Drawing.Point(286, 66);
            txtLastName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new System.Drawing.Size(110, 23);
            txtLastName.TabIndex = 2;
            txtLastName.TextChanged += txtLastName_TextChanged;
            // 
            // txtAddress
            // 
            txtAddress.Location = new System.Drawing.Point(286, 91);
            txtAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new System.Drawing.Size(110, 23);
            txtAddress.TabIndex = 3;
            // 
            // txtPhone
            // 
            txtPhone.Location = new System.Drawing.Point(286, 140);
            txtPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new System.Drawing.Size(110, 23);
            txtPhone.TabIndex = 4;
            // 
            // txtEmail
            // 
            txtEmail.Location = new System.Drawing.Point(286, 116);
            txtEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new System.Drawing.Size(110, 23);
            txtEmail.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(238, 71);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(40, 15);
            label1.TabIndex = 6;
            label1.Text = "Nom :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(221, 96);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(54, 15);
            label2.TabIndex = 7;
            label2.Text = "Adresse :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(234, 121);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(42, 15);
            label3.TabIndex = 8;
            label3.Text = "Email :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(206, 146);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(68, 15);
            label4.TabIndex = 9;
            label4.Text = "Téléphone :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(191, 170);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(83, 15);
            label5.TabIndex = 10;
            label5.Text = "Mot de Passe :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(222, 46);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(55, 15);
            label6.TabIndex = 11;
            label6.Text = "Prénom :";
            // 
            // txtmdp
            // 
            txtmdp.Location = new System.Drawing.Point(286, 165);
            txtmdp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            txtmdp.Name = "txtmdp";
            txtmdp.Size = new System.Drawing.Size(110, 23);
            txtmdp.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(309, 7);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(56, 15);
            label7.TabIndex = 13;
            label7.Text = "BT COOK";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(221, 243);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(241, 15);
            label8.TabIndex = 14;
            label8.Text = "Si vous avez déjà un compte connectez vous";
            // 
            // btnLogin
            // 
            btnLogin.Location = new System.Drawing.Point(0, 0);
            btnLogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new System.Drawing.Size(66, 17);
            btnLogin.TabIndex = 0;
            // 
            // btnLogin2
            // 
            btnLogin2.Location = new System.Drawing.Point(270, 279);
            btnLogin2.Name = "btnLogin2";
            btnLogin2.Size = new System.Drawing.Size(147, 23);
            btnLogin2.TabIndex = 15;
            btnLogin2.Text = "Se connecter";
            btnLogin2.UseVisualStyleBackColor = true;
            btnLogin2.Click += button1_Click;
            // 
            // FormRegister
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(700, 338);
            Controls.Add(btnLogin2);
            Controls.Add(btnLogin);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txtmdp);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtEmail);
            Controls.Add(txtPhone);
            Controls.Add(txtAddress);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(inscrirefinal);
            Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            Name = "FormRegister";
            Text = "FormRegister";
            Load += FormRegister_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button inscrirefinal;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtmdp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnLogin2;
    }
}