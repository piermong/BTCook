﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace projet_final_new
{
    public partial class FormDelivery : Form
    {
        private List<Plat> panier;

        public FormDelivery(List<Plat> panierRecupere)
        {
            InitializeComponent();
            panier = panierRecupere ?? new List<Plat>(); // Vérifie que la liste n'est pas nulle
            AfficherResumeCommande();
        }

        // Événement Load : peut être utilisé pour initialiser des éléments
        private void FormDelivery_Load(object sender, EventArgs e)
        {
            // Logique d'initialisation lors du chargement du formulaire
            // Exemple : initialiser des champs, des labels, etc.
            Console.WriteLine("FormDelivery est chargé !");
        }

        private void CalculerTotal()
        {
            decimal total = panier.Sum(p => p.Prix); // Additionne les prix
            lblTotal.Text = $"Total : {total} €"; // Affiche le total
        }

        private void AfficherResumeCommande()
        {
            if (panier.Count > 0)
            {
                dgvResumer.DataSource = null; // Réinitialise
                dgvResumer.DataSource = panier; // Affiche le panier
                CalculerTotal(); // Affiche le total
            }
            else
            {
                MessageBox.Show("Aucun plat dans le panier.");
            }
        }

        // Événement pour gérer les changements de texte dans textBox2
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        // Événement pour gérer les clics sur lblTotal
        private void lblTotal_Click(object sender, EventArgs e)
        {
            // Exemple : affiche un message ou met à jour un champ
            MessageBox.Show("Tu as cliqué sur le label Total !");
        }

        private void btnCommandefinal_Click(object sender, EventArgs e)
        {
            // Vérifie si le panier contient des plats
            if (dgvResumer.Rows.Count > 0)
            {
                // Récupère la station choisie par le client
                string stationClient = cmbMetro.SelectedItem?.ToString();
                if (string.IsNullOrEmpty(stationClient))
                {
                    MessageBox.Show("Sélectionne une station de métro !");
                    return;
                }

                // Récupère la notation de la commande depuis textBox2 (peut être null)
                string notationCommande = textBox2.Text; // Cela peut être un message ou null

                // Récupère l'email du client
                string emailClient = FormLogin.EmailUtilisateur; // Email du client

                // Récupère le matricule du client via l'email
                int matriculeClient = GetMatriculeClientByEmail(emailClient);
                if (matriculeClient == -1)
                {
                    MessageBox.Show("Aucun client trouvé avec cet email !");
                    return;
                }

                HashSet<int> matriculesCuisiniers = new HashSet<int>(); // Pour éviter les doublons
                List<string> nomsPlats = new List<string>(); // Liste pour les noms des plats
                decimal total = 0;

                // Liste pour stocker les stations de métro des plats
                HashSet<string> stationsPlats = new HashSet<string>();

                // Parcours tous les plats du panier pour récupérer les informations nécessaires
                foreach (DataGridViewRow row in dgvResumer.Rows)
                {
                    string nomPlat = row.Cells["nom"].Value?.ToString(); // Nom du plat
                    decimal prixPlat = Convert.ToDecimal(row.Cells["Prix"].Value); // Prix du plat

                    if (!string.IsNullOrEmpty(nomPlat))
                    {
                        // Ajoute le nom du plat au résumé
                        nomsPlats.Add(nomPlat);

                        // Récupère le matricule des cuisiniers associés à ce plat
                        List<int> cuisiniers = GetCuisiniersByPlat(nomPlat);
                        foreach (var matricule in cuisiniers)
                        {
                            matriculesCuisiniers.Add(matricule);
                        }

                        // Récupère la station de métro pour ce plat et l'ajoute à la liste des stations
                        string stationPlat = GetStationMetroFromDatabase(nomPlat);
                        if (!string.IsNullOrEmpty(stationPlat))
                        {
                            stationsPlats.Add(stationPlat); // Ajoute la station (sans doublon)
                        }

                        total += prixPlat; // Ajoute le prix au total
                    }
                }

                int matriculeCommande = CreateCommande(matriculeClient, notationCommande, nomsPlats, total, matriculesCuisiniers.ToList());

                if (matriculeCommande > 0)
                {
                    // Envoie aussi le matricule de commande à FormMetro (ou FormChemin si tu préfères)
                    FormMetro metroForm = new FormMetro(stationsPlats.ToList(), stationClient, matriculeCommande);
                    metroForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Erreur lors de la création de la commande.");
                }
            }
            else
            {
                MessageBox.Show("Ton panier est vide !");
            }
        }




        // Méthode pour récupérer le matricule client par email
        private int GetMatriculeClientByEmail(string email)
        {
            int matriculeClient = -1;
            string query = "SELECT matriculeUtilisateur FROM UTILISATEUR WHERE email = @Email";

            try
            {
                string connectionString = "Server=localhost;Database=BTCook;User ID=root;Password=root";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", email);
                        var result = command.ExecuteScalar();
                        matriculeClient = result != null ? Convert.ToInt32(result) : -1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la récupération du matricule client : {ex.Message}");
            }

            return matriculeClient;
        }


        // Méthode pour récupérer les matricules des cuisiniers associés à un plat
        private List<int> GetCuisiniersByPlat(string nomPlat)
        {
            List<int> matriculesCuisiniers = new List<int>();
            string query = "SELECT matriculeCuisinier FROM PLAT WHERE nom = @NomPlat";

            try
            {
                string connectionString = "Server=localhost;Database=BTCook;User ID=root;Password=root";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@NomPlat", nomPlat);
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                matriculesCuisiniers.Add(reader.GetInt32(0));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la récupération des cuisiniers pour le plat {nomPlat} : {ex.Message}");
            }

            return matriculesCuisiniers;
        }

        // Méthode pour créer une commande dans la base de données
        private int CreateCommande(int matriculeClient, string notationCommande, List<string> nomsPlats, decimal total, List<int> matriculesCuisiniers)
        {
            int matriculeCommande = -1;

            string query = "INSERT INTO COMMANDE (dateDeCommande, heureDépart, notationDeCommande, matriculeClient, prixtotal, resumer, matriculesCuisiniers) " +
                           "VALUES (@DateDeCommande, @HeureDépart, @NotationDeCommande, @MatriculeClient, @PrixTotal, @Resumer, @MatriculesCuisiniers); " +
                           "SELECT LAST_INSERT_ID();";

            try
            {
                string connectionString = "Server=localhost;Database=BTCook;User ID=root;Password=root";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@DateDeCommande", DateTime.Now);
                        command.Parameters.AddWithValue("@HeureDépart", DateTime.Now);

                        if (string.IsNullOrEmpty(notationCommande))
                            command.Parameters.AddWithValue("@NotationDeCommande", DBNull.Value);
                        else
                            command.Parameters.AddWithValue("@NotationDeCommande", notationCommande);

                        command.Parameters.AddWithValue("@MatriculeClient", matriculeClient);
                        command.Parameters.AddWithValue("@PrixTotal", total);
                        command.Parameters.AddWithValue("@Resumer", string.Join(", ", nomsPlats));

                        string matriculesCuisiniersString = string.Join(",", matriculesCuisiniers);
                        command.Parameters.AddWithValue("@MatriculesCuisiniers", matriculesCuisiniersString);

                        // Exécution + récupération de l'ID
                        matriculeCommande = Convert.ToInt32(command.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la création de la commande : {ex.Message}");
            }

            return matriculeCommande;
        }





        private string GetStationMetroFromDatabase(string nomPlat)
        {
            string stationMetro = null;
            string query = "SELECT metro FROM PLAT WHERE nom = @NomPlat";

            try
            {
                string connectionString = "Server=localhost;Database=BTCook;User ID=root;Password=root";
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@NomPlat", nomPlat);
                        var result = command.ExecuteScalar();
                        if (result != null)
                        {
                            stationMetro = result.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la récupération de la station métro : {ex.Message}");
            }

            return stationMetro;
        }

    }
}



