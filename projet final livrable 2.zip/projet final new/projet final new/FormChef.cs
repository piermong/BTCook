﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet_final_new
{
    public partial class FormChef : Form
    {

        // Connection string - remplace ces valeurs par les tiens
        private string connectionString = "Server=localhost; Database=BTCook; Uid=root; Pwd=root;";

        public FormChef()
        {
            InitializeComponent();
        }

        private void btCréation_Click(object sender, EventArgs e)
        {
            // Récupérer les valeurs des champs
            string ingredients = txtIngredients.Text;
            decimal prix;
            int quantite;
            string origine = txtOrigine.Text;
            string nom = txtNom.Text;
            string type = cmbType.SelectedItem?.ToString();
            string metro = cmbMetro.SelectedItem?.ToString();

            // Validation des entrées
            if (string.IsNullOrWhiteSpace(ingredients) ||
                !decimal.TryParse(txtPrix.Text, out prix) ||
                !int.TryParse(txtQuantité.Text, out quantite) ||
                string.IsNullOrWhiteSpace(origine) ||
                string.IsNullOrWhiteSpace(nom) ||
                string.IsNullOrWhiteSpace(type) ||
                string.IsNullOrWhiteSpace(metro))
            {
                MessageBox.Show("Tous les champs doivent être remplis correctement.");
                return;
            }

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO PLAT (ingrédients, prix, quantité, origine, nom, type,metro) " +
                                   "VALUES (@ingredients, @prix, @quantite, @origine, @nom, @type, @metro)";

                    using (MySqlCommand cmd = new MySqlCommand(query, connection))
                    {
                        // Ajouter les paramètres à la commande
                        cmd.Parameters.AddWithValue("@ingredients", ingredients);
                        cmd.Parameters.AddWithValue("@prix", prix);
                        cmd.Parameters.AddWithValue("@quantite", quantite);
                        cmd.Parameters.AddWithValue("@origine", origine);
                        cmd.Parameters.AddWithValue("@nom", nom);
                        cmd.Parameters.AddWithValue("@type", type);
                        cmd.Parameters.AddWithValue("@metro", metro);
                        // Exécuter la requête
                        cmd.ExecuteNonQuery();
                    }
                }

                // Confirmer la création
                MessageBox.Show("Plat créé avec succès !");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Une erreur est survenue : " + ex.Message);
            }
        }


        private void txtIngredients_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPrix_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQuantité_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtOrigine_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNom_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbMetro_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FormChef_Load(object sender, EventArgs e)
        {

        }
    }
}
